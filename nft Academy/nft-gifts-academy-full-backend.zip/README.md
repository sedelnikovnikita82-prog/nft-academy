# NFT Gifts Academy — Phone + Email + Telegram

## Что внутри

- Node.js + Express backend
- PostgreSQL
- Регистрация по телефону через Twilio Verify
- Регистрация по email через SMTP + одноразовый код
- Регистрация через официальный Telegram Login Widget
- Session-based авторизация
- Rate limiting
- Готовая папка `public/` с frontend

## 1. Установка

Нужен Node.js 18+.

```bash
npm install
```

## 2. PostgreSQL

Создайте базу данных:

```sql
CREATE DATABASE nft_gifts;
```

Затем выполните `schema.sql`.

Например через psql:

```bash
psql -U postgres -d nft_gifts -f schema.sql
```

## 3. Настройка .env

Скопируйте `.env.example` в `.env` и заполните значения.

```bash
cp .env.example .env
```

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

### Twilio

Нужны:
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_VERIFY_SERVICE_SID

Создайте Verify Service в Twilio Console.

### Email

Заполните SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS и EMAIL_FROM.

Для Gmail обычно нужен App Password, а не обычный пароль аккаунта.

### Telegram

1. Откройте BotFather в Telegram.
2. Создайте бота через `/newbot`.
3. Получите bot token.
4. Запишите username бота без `@` в `TELEGRAM_BOT_USERNAME`.
5. Для Login Widget домен сайта должен быть настроен для бота через BotFather (`/setdomain`).

Важно: Telegram Login Widget — это авторизация, а не просто ссылка на `t.me`.

## 4. Запуск

```bash
npm start
```

Откройте:

http://localhost:3000

## 5. Проверка

Проверить backend:

http://localhost:3000/api/health

Должно вернуться:

```json
{"ok":true}
```

## 6. Что поменять перед публикацией

- Использовать HTTPS.
- Поставить длинный SESSION_SECRET.
- Не публиковать `.env`.
- Для production использовать managed PostgreSQL.
- Настроить домен для Telegram Login.
- Проверить лимиты Twilio и SMTP.
