require("dotenv").config();

const express = require("express");
const session = require("express-session");
const pgSession = require("connect-pg-simple")(session);
const rateLimit = require("express-rate-limit");
const nodemailer = require("nodemailer");
const crypto = require("crypto");
const { Pool } = require("pg");
const pool = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.set("trust proxy", 1);
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  store: new pgSession({
    pool,
    tableName: "user_sessions",
    createTableIfMissing: true
  }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

const codeLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, message: "Слишком много попыток. Попробуйте позже." }
});

function normalizePhone(phone) {
  return String(phone || "").trim().replace(/[^\d+]/g, "");
}

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function generateCode() {
  return String(crypto.randomInt(100000, 1000000));
}

function hashCode(code) {
  return crypto.createHash("sha256").update(String(code)).digest("hex");
}

async function saveUser({ name, phone, email, telegram }) {
  const q = `
    INSERT INTO users (
      name, phone, email, telegram_id, telegram_username,
      telegram_first_name, telegram_last_name, last_login_at
    )
    VALUES ($1,$2,$3,$4,$5,$6,$7,NOW())
    ON CONFLICT DO NOTHING
    RETURNING id
  `;
  const values = [
    name || null,
    phone || null,
    email || null,
    telegram?.id ? String(telegram.id) : null,
    telegram?.username || null,
    telegram?.first_name || null,
    telegram?.last_name || null
  ];
  const inserted = await pool.query(q, values);
  if (inserted.rowCount) return inserted.rows[0].id;

  let lookup;
  if (phone) lookup = await pool.query("SELECT id FROM users WHERE phone=$1", [phone]);
  else if (email) lookup = await pool.query("SELECT id FROM users WHERE email=$1", [email]);
  else lookup = await pool.query("SELECT id FROM users WHERE telegram_id=$1", [String(telegram.id)]);

  if (!lookup.rowCount) throw new Error("Не удалось создать пользователя");
  return lookup.rows[0].id;
}

function setVerifiedSession(req, userId) {
  req.session.userId = userId;
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true });
});

app.get("/api/config", (req, res) => {
  res.json({
    ok: true,
    telegramBotUsername: process.env.TELEGRAM_BOT_USERNAME || ""
  });
});

app.post("/api/send-phone-code", codeLimiter, async (req, res) => {
  try {
    const { name, phone } = req.body;
    const normalized = normalizePhone(phone);

    if (!name || normalized.length < 8) {
      return res.status(400).json({ ok: false, message: "Введите имя и корректный номер телефона." });
    }

    if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_VERIFY_SERVICE_SID) {
      return res.status(500).json({ ok: false, message: "Twilio ещё не настроен на сервере." });
    }

    const auth = Buffer.from(
      `${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`
    ).toString("base64");

    const body = new URLSearchParams({
      To: normalized,
      Channel: "sms"
    });

    const response = await fetch(
      `https://verify.twilio.com/v2/Services/${process.env.TWILIO_VERIFY_SERVICE_SID}/Verifications`,
      {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body
      }
    );

    const data = await response.json();

    if (!response.ok) {
      console.error("Twilio error:", data);
      return res.status(400).json({ ok: false, message: data.message || "Не удалось отправить SMS." });
    }

    req.session.pendingPhone = normalized;
    req.session.pendingName = String(name).trim();

    res.json({ ok: true, message: "Код отправлен по SMS." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, message: "Ошибка сервера при отправке SMS." });
  }
});

app.post("/api/verify-phone-code", codeLimiter, async (req, res) => {
  try {
    const code = String(req.body.code || "").trim();
    const phone = req.session.pendingPhone;
    const name = req.session.pendingName;

    if (!phone || !code) {
      return res.status(400).json({ ok: false, message: "Сессия регистрации не найдена." });
    }

    const auth = Buffer.from(
      `${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`
    ).toString("base64");

    const body = new URLSearchParams({
      To: phone,
      Code: code
    });

    const response = await fetch(
      `https://verify.twilio.com/v2/Services/${process.env.TWILIO_VERIFY_SERVICE_SID}/VerificationCheck`,
      {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body
      }
    );

    const data = await response.json();

    if (!response.ok || data.status !== "approved") {
      return res.status(400).json({ ok: false, message: "Неверный или просроченный код." });
    }

    const userId = await saveUser({ name, phone });
    setVerifiedSession(req, userId);

    delete req.session.pendingPhone;
    delete req.session.pendingName;

    res.json({ ok: true, message: "Телефон подтверждён. Регистрация завершена." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, message: "Ошибка проверки SMS-кода." });
  }
});

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: String(process.env.SMTP_SECURE).toLowerCase() === "true",
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

app.post("/api/send-email-code", codeLimiter, async (req, res) => {
  try {
    const { name } = req.body;
    const email = normalizeEmail(req.body.email);

    if (!name || !validEmail(email)) {
      return res.status(400).json({ ok: false, message: "Введите имя и корректный email." });
    }

    if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.EMAIL_FROM) {
      return res.status(500).json({ ok: false, message: "Email SMTP ещё не настроен на сервере." });
    }

    const code = generateCode();

    req.session.pendingEmail = email;
    req.session.pendingEmailName = String(name).trim();
    req.session.pendingEmailCodeHash = hashCode(code);
    req.session.pendingEmailExpires = Date.now() + 10 * 60 * 1000;

    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: email,
      subject: "Код регистрации — NFT Gifts Academy",
      text: `Ваш код регистрации: ${code}\n\nКод действителен 10 минут.`,
      html: `
        <div style="font-family:Arial,sans-serif;line-height:1.6">
          <h2>NFT Gifts Academy</h2>
          <p>Ваш код регистрации:</p>
          <p style="font-size:32px;font-weight:700;letter-spacing:6px">${code}</p>
          <p>Код действителен 10 минут.</p>
        </div>
      `
    });

    res.json({ ok: true, message: "Код отправлен на email." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, message: "Не удалось отправить email." });
  }
});

app.post("/api/verify-email-code", codeLimiter, async (req, res) => {
  try {
    const code = String(req.body.code || "").trim();

    if (!req.session.pendingEmail || !req.session.pendingEmailCodeHash) {
      return res.status(400).json({ ok: false, message: "Сессия регистрации не найдена." });
    }

    if (Date.now() > Number(req.session.pendingEmailExpires || 0)) {
      return res.status(400).json({ ok: false, message: "Код истёк. Запросите новый." });
    }

    if (hashCode(code) !== req.session.pendingEmailCodeHash) {
      return res.status(400).json({ ok: false, message: "Неверный код." });
    }

    const userId = await saveUser({
      name: req.session.pendingEmailName,
      email: req.session.pendingEmail
    });

    setVerifiedSession(req, userId);

    delete req.session.pendingEmail;
    delete req.session.pendingEmailName;
    delete req.session.pendingEmailCodeHash;
    delete req.session.pendingEmailExpires;

    res.json({ ok: true, message: "Email подтверждён. Регистрация завершена." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, message: "Ошибка проверки email-кода." });
  }
});

// Telegram Login Widget verification.
// Telegram sends auth data to the frontend callback; the frontend posts it here.
// The backend verifies the hash using HMAC-SHA256 as required by Telegram.
function verifyTelegramAuth(data) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken) return false;

  const receivedHash = data.hash;
  if (!receivedHash) return false;

  const checkString = Object.keys(data)
    .filter(k => k !== "hash" && data[k] !== undefined && data[k] !== null)
    .sort()
    .map(k => `${k}=${data[k]}`)
    .join("\n");

  const secretKey = crypto
    .createHash("sha256")
    .update(botToken)
    .digest();

  const calculatedHash = crypto
    .createHmac("sha256", secretKey)
    .update(checkString)
    .digest("hex");

  const a = Buffer.from(calculatedHash, "hex");
  const b = Buffer.from(receivedHash, "hex");
  if (a.length !== b.length) return false;

  return crypto.timingSafeEqual(a, b);
}

app.post("/api/telegram-auth", async (req, res) => {
  try {
    const data = req.body || {};

    if (!verifyTelegramAuth(data)) {
      return res.status(401).json({ ok: false, message: "Не удалось подтвердить Telegram." });
    }

    const authAge = Math.floor(Date.now() / 1000) - Number(data.auth_date || 0);
    if (authAge > 24 * 60 * 60) {
      return res.status(401).json({ ok: false, message: "Данные Telegram устарели." });
    }

    const userId = await saveUser({
      name: [data.first_name, data.last_name].filter(Boolean).join(" ") || data.username || "Telegram user",
      telegram: {
        id: data.id,
        username: data.username,
        first_name: data.first_name,
        last_name: data.last_name
      }
    });

    setVerifiedSession(req, userId);

    res.json({ ok: true, message: "Telegram подтверждён. Регистрация завершена." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok: false, message: "Ошибка Telegram авторизации." });
  }
});

app.get("/api/me", async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ ok: false, authenticated: false });
  }

  const result = await pool.query(
    `SELECT id, name, phone, email, telegram_username, created_at
     FROM users WHERE id=$1`,
    [req.session.userId]
  );

  if (!result.rowCount) {
    return res.status(401).json({ ok: false, authenticated: false });
  }

  res.json({ ok: true, authenticated: true, user: result.rows[0] });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.use(express.static("public"));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ ok: false, message: "Внутренняя ошибка сервера." });
});

app.listen(PORT, () => {
  console.log(`NFT Gifts Academy running on http://localhost:${PORT}`);
});
